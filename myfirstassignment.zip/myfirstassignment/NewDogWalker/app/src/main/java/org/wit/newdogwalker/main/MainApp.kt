package org.wit.newdogwalker.main

import android.app.Application
import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info
import org.wit.newdogwalker.models.NewDogWalkerMemStore
import org.wit.newdogwalker.models.NewDogWalkerModel
import org.wit.newdogwalker.models.NewDogWalkerJSONStore
import org.wit.newdogwalker.models.NewDogWalkerStore

class MainApp : Application(), AnkoLogger {
//val dogWalk = ArrayList<NewDogWalkerModel>()
lateinit var dogWalkerStore : NewDogWalkerStore

    override fun onCreate() {
        super.onCreate()

        dogWalkerStore = NewDogWalkerJSONStore(applicationContext)

        info("NewDogWALKER  started ==> ")




//        dogWalk.add(NewDogWalkerModel("jr","rottweiler.","waterford"))
//        dogWalk.add(NewDogWalkerModel("jr","Labrador.","waterford"))
//        dogWalk.add(NewDogWalkerModel("jr","Bulldogs.","waterford"))

    }
}