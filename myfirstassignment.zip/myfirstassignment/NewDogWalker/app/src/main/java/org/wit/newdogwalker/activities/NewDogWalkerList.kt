package org.wit.newdogwalker.activities

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_newdogwalker_list.*
import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info
import org.jetbrains.anko.intentFor
import org.wit.newdogwalker.R
import org.wit.newdogwalker.main.MainApp
import org.jetbrains.anko.startActivityForResult
import org.wit.newdogwalker.models.NewDogWalkerModel

class NewDogWalkerList: AppCompatActivity(),NewDogWalkerListener, AnkoLogger {

    lateinit var app: MainApp

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_newdogwalker_list)
        app = application as MainApp
        val layoutManager = LinearLayoutManager(this)
        recyclerView.layoutManager = layoutManager
//        recyclerView.adapter = NewDogWalkerAdapter(app.dogWalkermemStore.findAll(),this)
        loadNewDogWalker()

        toolbar.title = title
        setSupportActionBar(toolbar)
    }



    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.item_add -> startActivityForResult<MainActivity>(0)
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onNewDogWalkerClick(doginfo: NewDogWalkerModel) {
        startActivityForResult(intentFor<MainActivity>().putExtra("DogWalker_edit", doginfo), 0 )

    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        loadNewDogWalker()
        super.onActivityResult(requestCode, resultCode, data)
    }
    private fun loadNewDogWalker() {
        showNewDogWalker(app.dogWalkerStore.findAll())
    }

    fun showNewDogWalker (dogshow: List<NewDogWalkerModel>) {
        info { "showNewDogWalkermarks: ${dogshow}" }
        recyclerView.adapter = NewDogWalkerAdapter(dogshow, this)
        recyclerView.adapter?.notifyDataSetChanged()
    }


}


