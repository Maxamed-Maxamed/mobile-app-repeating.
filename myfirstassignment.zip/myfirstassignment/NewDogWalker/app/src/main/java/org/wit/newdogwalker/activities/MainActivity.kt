package org.wit.newdogwalker.activities
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.RatingBar
import android.widget.Toast

import kotlinx.android.synthetic.main.activity_main.*

import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info
import org.jetbrains.anko.toast
import org.wit.newdogwalker.R
import org.wit.newdogwalker.helpers.readImage
import org.wit.newdogwalker.helpers.readImageFromPath
import org.wit.newdogwalker.helpers.showImagePicker
import org.wit.newdogwalker.main.MainApp
import org.wit.newdogwalker.models.NewDogWalkerModel
import kotlin.math.absoluteValue


class MainActivity : AppCompatActivity(), AnkoLogger {
    var dogwalkermodels = NewDogWalkerModel()
    lateinit var app : MainApp
    var edit = false
    val IMAGE_REQUEST = 1



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        app = application as MainApp

        if (intent.hasExtra("DogWalker_edit")) {
            edit = true
            dogwalkermodels = intent.extras?.getParcelable<NewDogWalkerModel>("DogWalker_edit")!!
                textDogName.setText(dogwalkermodels.dogname)
                textDogBreed.setText(dogwalkermodels.dogbreed)
                textDogAddress.setText(dogwalkermodels.dogaddress)
               ratingBar.rating = dogwalkermodels.ratingbar

            dogImage.setImageBitmap(readImageFromPath(this, dogwalkermodels.image))
            if (dogwalkermodels.image !=null){

                chooseImage.setText(R.string.change_dog_image)
            }
            btnAdd.setText(R.string.save_dog)
        }

        btnAdd.setOnClickListener {
            dogwalkermodels.dogname = textDogName.text.toString()
            dogwalkermodels.dogbreed =textDogBreed.text.toString()
            dogwalkermodels.dogaddress = textDogAddress.text.toString()
            dogwalkermodels.ratingbar = ratingBar.rating.toFloat()

            if (dogwalkermodels.dogname.isEmpty()) {
                toast(R.string.enter_dogname_title)
            }
            else{
                if (edit) {
                    app.dogWalkerStore.update(dogwalkermodels.copy())
                }
                else {
                    app.dogWalkerStore.create(dogwalkermodels.copy())
                }
            }
            info("add Button Pressed: $textDogName")
            setResult(AppCompatActivity.RESULT_OK)
            finish()

        }
        toolbarAdd.title = title
        setSupportActionBar(toolbarAdd)
        chooseImage.setOnClickListener {
            showImagePicker(this, IMAGE_REQUEST)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_newdogwalker, menu)
        if (edit && menu != null) menu.getItem(0).setVisible(true)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {
            R.id.item_delete -> {
                app.dogWalkerStore.delete(dogwalkermodels)
                finish()
            }
            R.id.item_cancel -> {
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            IMAGE_REQUEST -> {
                if (data != null) {
                    dogwalkermodels.image = data.getData().toString()
                    dogImage.setImageBitmap(readImage(this,resultCode,data))
                    chooseImage.setText(R.string.change_dog_image)
                }
            }
        }
    }

}