package org.wit.newdogwalker.models
import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import org.jetbrains.anko.AnkoLogger
import org.wit.newdogwalker.helpers.*
import java.util.*
val JSON_FILE = "newdogwalker.json"
val gsonBuilder = GsonBuilder().setPrettyPrinting().create()
val listType = object : TypeToken<java.util.ArrayList<NewDogWalkerModel>>() {}.type

fun generateRandomId(): Long {
    return Random().nextLong()
}
class NewDogWalkerJSONStore : NewDogWalkerStore, AnkoLogger {

    val context: Context
    var dogs = mutableListOf<NewDogWalkerModel>()

    constructor (context: Context) {
        this.context = context
        if (exists(context, JSON_FILE)) {
            deserialize()
        }
    }




    override fun findAll(): List<NewDogWalkerModel> {
        return dogs
    }

    override fun create(dogWalkerStore: NewDogWalkerModel) {
        dogWalkerStore.id = generateRandomId()
        dogs.add(dogWalkerStore)
        serialize()
    }


    override fun update(dogUpdate: NewDogWalkerModel) {
        var foundDog: NewDogWalkerModel? = dogs.find { d -> d.id == dogUpdate.id  }
        if (foundDog !=null)
        {
            foundDog.dogname = dogUpdate.dogname
            foundDog.dogbreed = dogUpdate.dogbreed
            foundDog.dogaddress = dogUpdate.dogaddress
            foundDog.image = dogUpdate.image
            foundDog.ratingbar = dogUpdate.ratingbar
        }
        serialize()
        
    }

    override fun delete(dogDelete: NewDogWalkerModel) {
        dogs.remove(dogDelete)
        serialize()
    }

    private fun serialize() {
        val jsonString = gsonBuilder.toJson(dogs, listType)
        write(context, JSON_FILE, jsonString)
    }
    private fun deserialize() {
        val jsonString = read(context, JSON_FILE)
        dogs = Gson().fromJson(jsonString, listType)
    }
}