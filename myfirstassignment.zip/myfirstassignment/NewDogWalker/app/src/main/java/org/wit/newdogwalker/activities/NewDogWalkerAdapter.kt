package org.wit.newdogwalker.activities

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.card_newdogwalker.view.*
import org.wit.newdogwalker.R
import org.wit.newdogwalker.helpers.readImageFromPath
import org.wit.newdogwalker.models.NewDogWalkerModel
interface NewDogWalkerListener {
    fun onNewDogWalkerClick(doginfo: NewDogWalkerModel)
}
class NewDogWalkerAdapter constructor(private var dogplace : List<NewDogWalkerModel>,

                                      private val listener: NewDogWalkerListener

                                      ):
RecyclerView.Adapter<NewDogWalkerAdapter.MainHolder>()
{

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainHolder {
      return MainHolder(
          LayoutInflater.from(parent.context).inflate(
              R.layout.card_newdogwalker,
              parent,
              false
      )
      )
    }

    override fun onBindViewHolder(holder: MainHolder, position: Int) {
        val doginfo = dogplace[holder.adapterPosition]
        holder.bind(doginfo,listener)
//        private final val listener: NewDogWalkerListener
    }

    override fun getItemCount(): Int = dogplace.size
//Returns the size of the collection.
//A generic ordered collection of elements.
// Methods in this interface support
// only read-only access to the list;
// read/write access is supported
// through the MutableList interface.




    class MainHolder  constructor(itemView: View): RecyclerView.ViewHolder(itemView) {
        fun bind(dogs: NewDogWalkerModel, listener: NewDogWalkerListener){
            itemView.textDogName1.text =dogs.dogname
            itemView.textDogBreed1.text = dogs.dogbreed
            itemView.imageIcon.setImageBitmap(readImageFromPath(itemView.context, dogs.image))
//            itemView.ratingBarID.rating
            itemView.ratingBarID.rating =dogs.ratingbar
            itemView.setOnClickListener { listener.onNewDogWalkerClick(dogs) }

        }
    }



}

