package org.wit.newdogwalker.models

interface NewDogWalkerStore {
    fun findAll(): List<NewDogWalkerModel>
    fun create(dogWalkerStore: NewDogWalkerModel)
    fun update(dogUpdate: NewDogWalkerModel)
    fun delete(dogDelete: NewDogWalkerModel)







}