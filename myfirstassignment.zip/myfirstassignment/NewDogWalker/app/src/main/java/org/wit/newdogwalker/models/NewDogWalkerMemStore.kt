package org.wit.newdogwalker.models

import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info

class NewDogWalkerMemStore : NewDogWalkerStore, AnkoLogger {

    val dogWalker = ArrayList<NewDogWalkerModel>()


   override fun findAll(): List<NewDogWalkerModel>{
   return dogWalker
   }

    override fun create(dogWalkerStore: NewDogWalkerModel) {
        dogWalker.add(dogWalkerStore)
    }

    override fun update(dogUpdate: NewDogWalkerModel) {
        var foundDog: NewDogWalkerModel? = dogWalker.find { d -> d.id == dogUpdate.id  }
        if (foundDog !=null)
        {
            foundDog.dogname = dogUpdate.dogname
            foundDog.dogbreed = dogUpdate.dogbreed
            foundDog.dogaddress = dogUpdate.dogaddress
            foundDog.image = dogUpdate.image
            foundDog.ratingbar = dogUpdate.ratingbar
            logAll()
        }

    }

    override fun delete(dogDelete: NewDogWalkerModel) {
        dogWalker.remove(dogDelete)
    }

    fun logAll() {
        dogWalker.forEach{ info("${it}")  }
    }

}
